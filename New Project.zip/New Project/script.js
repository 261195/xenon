const express = require('express');
const bodyParser = require('body-parser');

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));

app.post('/login', (req, res) => {
  const email = req.body.email;
  const password = req.body.password;

  const query = `SELECT * FROM users WHERE email='${email}' AND password='${password}'`;

  connection.query(query, (error, results, fields) => {
    if (error) throw error;

    if (results.length > 0) {
      // successful login
      res.send('Login successful');
    } else {
      // invalid credentials
      res.send('Invalid email or password');
    }
  });
});


